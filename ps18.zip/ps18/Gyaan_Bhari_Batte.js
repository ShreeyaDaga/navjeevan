// To run mongodb in mac using terminal do these steps:
// 1) mongod --dbpath ~/data/db (Run this command in terminal)
// 2) mongosh (In another new terminal run this command to connect to the database)
// Now mongoDB suceesfully running

// Install following packages first
// npm install express mongodb ejs

// To run the Backend server - (node final_app.js)

// If you do any change close the server using cntrl + c and then start again using node final_app.js to see the change